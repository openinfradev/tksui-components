import{j as e}from"./jsx-runtime-ffb262ed.js";import{T as o}from"./TChip-da2a9bdd.js";import{n,T as C}from"./TToast-dec64875.js";import"./index-76fb7be0.js";import"./_commonjsHelpers-de833af9.js";import"./TIcon-06114f05.js";/* empty css                      */const O={title:"Input/TChip",component:o},t=r=>e.jsx("div",{style:{marginBottom:"16px",display:"flex",alignItems:"center"},children:r.children}),l=r=>e.jsxs(e.Fragment,{children:[e.jsxs(t,{children:[e.jsx(o,{...r,children:"hello"}),e.jsx(o,{...r,onRemove:()=>{n("삭제 이벤트 발생")},children:"hello"}),e.jsx(o,{...r,onRemove:()=>{n("삭제 이벤트 발생")},removeIcon:"clear",children:"hello"}),e.jsx(o,{...r,icon:"face",children:"hello"}),e.jsx(o,{...r,icon:"face",onRemove:()=>{n("삭제 이벤트 발생")},children:"hello"})]}),e.jsxs(t,{children:[e.jsx(o,{...r,primary:!0,children:"hello"}),e.jsx(o,{...r,primary:!0,onRemove:()=>{n("삭제 이벤트 발생")},children:"hello"}),e.jsx(o,{...r,primary:!0,onRemove:()=>{n("삭제 이벤트 발생")},removeIcon:"clear",children:"hello"}),e.jsx(o,{...r,primary:!0,icon:"face",children:"hello"}),e.jsx(o,{...r,primary:!0,icon:"face",onRemove:()=>{n("삭제 이벤트 발생")},children:"hello"})]}),e.jsxs(t,{children:[e.jsx(o,{...r,type:"outlined",children:"hello"}),e.jsx(o,{...r,type:"outlined",onRemove:()=>{n("삭제 이벤트 발생")},children:"hello"}),e.jsx(o,{...r,type:"outlined",onRemove:()=>{n("삭제 이벤트 발생")},removeIcon:"clear",children:"hello"}),e.jsx(o,{...r,type:"outlined",icon:"face",children:"hello"}),e.jsx(o,{...r,type:"outlined",icon:"face",onRemove:()=>{n("삭제 이벤트 발생")},children:"hello"})]}),e.jsxs(t,{children:[e.jsx(o,{...r,type:"outlined",primary:!0,children:"hello"}),e.jsx(o,{...r,type:"outlined",primary:!0,onRemove:()=>{n("삭제 이벤트 발생")},children:"hello"}),e.jsx(o,{...r,type:"outlined",primary:!0,onRemove:()=>{n("삭제 이벤트 발생")},removeIcon:"clear",children:"hello"}),e.jsx(o,{...r,type:"outlined",primary:!0,icon:"face",children:"hello"}),e.jsx(o,{...r,type:"outlined",primary:!0,icon:"face",onRemove:()=>{n("삭제 이벤트 발생")},children:"hello"})]}),e.jsx(C,{})]}),a={render:l,args:{onRemove:void 0,xsmall:!0}},m={render:l,args:{onRemove:void 0,small:!0}},i={render:l,args:{onRemove:void 0,medium:!0}},s={render:l,args:{onRemove:void 0,large:!0}},c={render:l,args:{onRemove:void 0,xlarge:!0}};var d,p,u;a.parameters={...a.parameters,docs:{...(d=a.parameters)==null?void 0:d.docs,source:{originalSource:`{
  render: NormalTemplate,
  args: {
    onRemove: undefined,
    xsmall: true
  }
}`,...(u=(p=a.parameters)==null?void 0:p.docs)==null?void 0:u.source}}};var h,x,v;m.parameters={...m.parameters,docs:{...(h=m.parameters)==null?void 0:h.docs,source:{originalSource:`{
  render: NormalTemplate,
  args: {
    onRemove: undefined,
    small: true
  }
}`,...(v=(x=m.parameters)==null?void 0:x.docs)==null?void 0:v.source}}};var j,y,R;i.parameters={...i.parameters,docs:{...(j=i.parameters)==null?void 0:j.docs,source:{originalSource:`{
  render: NormalTemplate,
  args: {
    onRemove: undefined,
    medium: true
  }
}`,...(R=(y=i.parameters)==null?void 0:y.docs)==null?void 0:R.source}}};var f,T,S;s.parameters={...s.parameters,docs:{...(f=s.parameters)==null?void 0:f.docs,source:{originalSource:`{
  render: NormalTemplate,
  args: {
    onRemove: undefined,
    large: true
  }
}`,...(S=(T=s.parameters)==null?void 0:T.docs)==null?void 0:S.source}}};var g,I,N;c.parameters={...c.parameters,docs:{...(g=c.parameters)==null?void 0:g.docs,source:{originalSource:`{
  render: NormalTemplate,
  args: {
    onRemove: undefined,
    xlarge: true
  }
}`,...(N=(I=c.parameters)==null?void 0:I.docs)==null?void 0:N.source}}};const b=["XSmall","Small","Medium","Large","XLarge"];export{s as Large,i as Medium,m as Small,c as XLarge,a as XSmall,b as __namedExportsOrder,O as default};
