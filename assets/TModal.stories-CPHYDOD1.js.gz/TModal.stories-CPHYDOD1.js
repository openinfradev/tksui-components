import{j as r}from"./jsx-runtime-D_zvdyIk.js";import{r as y}from"./index-BqztxKQk.js";import{A as M,R as C,a as p}from"./TButtonGroup-DkzWU4CD.js";import"./TTabItem-CKcer2mH.js";import"./TIcon-CYhWV6Ep.js";import"./index-DmlQtXDA.js";import"./index-C6xMosk4.js";import"./TBadge-B8yc9zRE.js";import"./UseValidator-DgLpkHEc.js";import"./TDropHolder-B7z40qzo.js";import"./THighlightText-pTj3K_4-.js";import"./TInputValidationHint-C1mvkrXU.js";import"./TChip-DgOBpbU4.js";import"./TTextField-C6MSjj1d.js";import"./TSwitch-YoEgX14L.js";const N={title:"Screen/TModal",component:M,args:{appId:"storybook-root",portalId:"storybook-root"}},e=E=>{const[R,m]=y.useState(!1),b=r.jsxs(r.Fragment,{children:[r.jsx(p,{size:"large",onClick:()=>m(!1),children:"취소"}),r.jsx(p,{size:"large",main:!0,children:"저장"})]});return C.setAppElement("#storybook-root"),r.jsxs(r.Fragment,{children:[r.jsx("div",{id:"test-test"}),r.jsx(p,{onClick:()=>m(!0),children:"모달 열기"}),r.jsx(M,{...E,title:"클러스터 생성",isOpen:R,onRequestClose:()=>m(!1),footer:b,children:"클러스터 생성 모달입니다."})]})},a={render:e,args:{small:!0}},s={render:e,args:{medium:!0}},t={render:e,args:{large:!0}},o={render:e,args:{xlarge:!0}},n={render:e,args:{xxlarge:!0}};var c,l,i;a.parameters={...a.parameters,docs:{...(c=a.parameters)==null?void 0:c.docs,source:{originalSource:`{
  render: Template,
  args: {
    small: true
  }
}`,...(i=(l=a.parameters)==null?void 0:l.docs)==null?void 0:i.source}}};var d,u,g;s.parameters={...s.parameters,docs:{...(d=s.parameters)==null?void 0:d.docs,source:{originalSource:`{
  render: Template,
  args: {
    medium: true
  }
}`,...(g=(u=s.parameters)==null?void 0:u.docs)==null?void 0:g.source}}};var x,j,S;t.parameters={...t.parameters,docs:{...(x=t.parameters)==null?void 0:x.docs,source:{originalSource:`{
  render: Template,
  args: {
    large: true
  }
}`,...(S=(j=t.parameters)==null?void 0:j.docs)==null?void 0:S.source}}};var T,f,h;o.parameters={...o.parameters,docs:{...(T=o.parameters)==null?void 0:T.docs,source:{originalSource:`{
  render: Template,
  args: {
    xlarge: true
  }
}`,...(h=(f=o.parameters)==null?void 0:f.docs)==null?void 0:h.source}}};var L,X,k;n.parameters={...n.parameters,docs:{...(L=n.parameters)==null?void 0:L.docs,source:{originalSource:`{
  render: Template,
  args: {
    xxlarge: true
  }
}`,...(k=(X=n.parameters)==null?void 0:X.docs)==null?void 0:k.source}}};const P=["Small","Medium","Large","XLarge","XXLarge"];export{t as Large,s as Medium,a as Small,o as XLarge,n as XXLarge,P as __namedExportsOrder,N as default};
