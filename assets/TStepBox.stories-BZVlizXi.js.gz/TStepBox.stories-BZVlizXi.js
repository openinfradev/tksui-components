import{j as e}from"./jsx-runtime-CKrituN3.js";import{r as c}from"./index-CBqU2yxZ.js";import{T as a,a as t}from"./TStepBox-D9Z1L6ga.js";import"./_commonjsHelpers-BosuxZz1.js";import"./TIcon-BNJ4MhZ5.js";import"./TButton-DTcO0l4q.js";import"./UseRipple-B0f24SXl.js";import"./uniqueId-BdmaqBQH.js";import"./toString-Biug5Hwg.js";const v={title:"DataContainer/TStepBox",component:a},d=p=>{const[i,l]=c.useState(1);return e.jsx(e.Fragment,{children:e.jsxs(a,{value:i,onChange:l,stepLabels:["설치환경 선택","스택 템플릿 선택","속성 입력","정책 템플릿 선택","정책 선택","확인 및 생성"],...p,children:[e.jsx(t,{children:e.jsx("div",{children:"Step 1 Content"})}),e.jsx(t,{children:e.jsx("div",{children:"Step 2 Content"})}),e.jsx(t,{children:e.jsx("div",{children:"Step 3 Content"})}),e.jsx(t,{children:e.jsx("div",{children:"Step 4 Content"})}),e.jsx(t,{children:e.jsx("div",{children:"Step 5 Content"})}),e.jsx(t,{children:e.jsx("div",{children:"Step 6 Content"})})]})})},r={render:d,args:{prevButtonLabel:"이전",nextButtonLabel:"다음",completeButtonLabel:"저장하기"}};var n,o,s;r.parameters={...r.parameters,docs:{...(n=r.parameters)==null?void 0:n.docs,source:{originalSource:`{
  render: Template,
  args: {
    prevButtonLabel: '이전',
    nextButtonLabel: '다음',
    completeButtonLabel: '저장하기'
  }
}`,...(s=(o=r.parameters)==null?void 0:o.docs)==null?void 0:s.source}}};const L=["Default"];export{r as Default,L as __namedExportsOrder,v as default};
