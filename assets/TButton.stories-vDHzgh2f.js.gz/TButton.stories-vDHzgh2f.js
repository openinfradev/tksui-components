import{j as r}from"./jsx-runtime-vNq4Oc-g.js";import{T as e}from"./TButton-wzgHEj5b.js";import"./index-4g5l5LRQ.js";import"./_commonjsHelpers-4gQjN7DL.js";import"./UseRipple-bKa6TkVL.js";import"./TIcon-Vi1lColy.js";const O={title:"Button/TButton",component:e},a=n=>r.jsxs(r.Fragment,{children:[r.jsx(e,{...n,children:"plain"}),r.jsx(e,{...n,primary:!0,children:"primary"}),r.jsx(e,{...n,main:!0,children:"main"}),r.jsx(e,{...n,point:!0,children:"point"}),r.jsx(e,{...n,rounded:!0,children:"rounded"}),r.jsx("br",{})," ",r.jsx("br",{}),r.jsx(e,{...n,disabled:!0,children:"plain"}),r.jsx(e,{...n,primary:!0,disabled:!0,children:"primary"}),r.jsx(e,{...n,main:!0,disabled:!0,children:"main"}),r.jsx(e,{...n,point:!0,disabled:!0,children:"point"}),r.jsx(e,{...n,rounded:!0,disabled:!0,children:"rounded"}),r.jsx("br",{})," ",r.jsx("br",{}),r.jsx(e,{...n,loading:!0,children:"plain"}),r.jsx(e,{...n,primary:!0,loading:!0,children:"primary"}),r.jsx(e,{...n,main:!0,loading:!0,children:"main"}),r.jsx(e,{...n,point:!0,loading:!0,children:"point"}),r.jsx(e,{...n,rounded:!0,loading:!0,children:"rounded"})]}),t={render:a,args:{xsmall:!0}},s={render:a,args:{small:!0}},o={render:a,args:{medium:!0}},d={render:a,args:{large:!0}},i={render:a,args:{xlarge:!0}};var m,l,u;t.parameters={...t.parameters,docs:{...(m=t.parameters)==null?void 0:m.docs,source:{originalSource:`{
  render: Template,
  args: {
    xsmall: true
  }
}`,...(u=(l=t.parameters)==null?void 0:l.docs)==null?void 0:u.source}}};var c,p,x;s.parameters={...s.parameters,docs:{...(c=s.parameters)==null?void 0:c.docs,source:{originalSource:`{
  render: Template,
  args: {
    small: true
  }
}`,...(x=(p=s.parameters)==null?void 0:p.docs)==null?void 0:x.source}}};var j,h,g;o.parameters={...o.parameters,docs:{...(j=o.parameters)==null?void 0:j.docs,source:{originalSource:`{
  render: Template,
  args: {
    medium: true
  }
}`,...(g=(h=o.parameters)==null?void 0:h.docs)==null?void 0:g.source}}};var b,S,T;d.parameters={...d.parameters,docs:{...(b=d.parameters)==null?void 0:b.docs,source:{originalSource:`{
  render: Template,
  args: {
    large: true
  }
}`,...(T=(S=d.parameters)==null?void 0:S.docs)==null?void 0:T.source}}};var y,L,X;i.parameters={...i.parameters,docs:{...(y=i.parameters)==null?void 0:y.docs,source:{originalSource:`{
  render: Template,
  args: {
    xlarge: true
  }
}`,...(X=(L=i.parameters)==null?void 0:L.docs)==null?void 0:X.source}}};const R=["XSmall","Small","Medium","Large","XLarge"];export{d as Large,o as Medium,s as Small,i as XLarge,t as XSmall,R as __namedExportsOrder,O as default};
