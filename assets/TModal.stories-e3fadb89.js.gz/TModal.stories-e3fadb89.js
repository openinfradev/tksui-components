import{j as r}from"./jsx-runtime-ffb262ed.js";import{r as w}from"./index-76fb7be0.js";import{T as k}from"./TModal-5fa4ad26.js";import{T as c}from"./TButton-2abaa3ab.js";import"./_commonjsHelpers-de833af9.js";import"./index-d3ea75b5.js";import"./index-9d475cdf.js";import"./TIcon-4c0f64bb.js";import"./UseRipple-565834b6.js";const z={title:"Screen/TModal",component:k,args:{containerId:"storybook-root"}},e=C=>{const[E,m]=w.useState(!1),O=r.jsxs(r.Fragment,{children:[r.jsx(c,{width:"50%",onClick:()=>m(!1),children:"취소"}),r.jsx(c,{width:"50%",main:!0,children:"저장"})]});return r.jsxs(r.Fragment,{children:[r.jsx(c,{onClick:()=>m(!0),children:"모달 열기"}),r.jsx(k,{...C,title:"클러스터 생성",isOpen:E,onRequestClose:()=>m(!1),footer:O})]})},a={render:e,args:{small:!0}},s={render:e,args:{medium:!0}},t={render:e,args:{large:!0}},o={render:e,args:{xlarge:!0}},n={render:e,args:{xxlarge:!0}};var d,p,l;a.parameters={...a.parameters,docs:{...(d=a.parameters)==null?void 0:d.docs,source:{originalSource:`{
  render: Template,
  args: {
    small: true
  }
}`,...(l=(p=a.parameters)==null?void 0:p.docs)==null?void 0:l.source}}};var i,u,g;s.parameters={...s.parameters,docs:{...(i=s.parameters)==null?void 0:i.docs,source:{originalSource:`{
  render: Template,
  args: {
    medium: true
  }
}`,...(g=(u=s.parameters)==null?void 0:u.docs)==null?void 0:g.source}}};var x,T,f;t.parameters={...t.parameters,docs:{...(x=t.parameters)==null?void 0:x.docs,source:{originalSource:`{
  render: Template,
  args: {
    large: true
  }
}`,...(f=(T=t.parameters)==null?void 0:T.docs)==null?void 0:f.source}}};var S,j,h;o.parameters={...o.parameters,docs:{...(S=o.parameters)==null?void 0:S.docs,source:{originalSource:`{
  render: Template,
  args: {
    xlarge: true
  }
}`,...(h=(j=o.parameters)==null?void 0:j.docs)==null?void 0:h.source}}};var L,X,M;n.parameters={...n.parameters,docs:{...(L=n.parameters)==null?void 0:L.docs,source:{originalSource:`{
  render: Template,
  args: {
    xxlarge: true
  }
}`,...(M=(X=n.parameters)==null?void 0:X.docs)==null?void 0:M.source}}};const A=["Small","Medium","Large","XLarge","XXLarge"];export{t as Large,s as Medium,a as Small,o as XLarge,n as XXLarge,A as __namedExportsOrder,z as default};
