import{j as s}from"./jsx-runtime-ffb262ed.js";import{T as j,n as e}from"./TToast-dec64875.js";import{T as o}from"./TButton-d81d8fd9.js";import"./index-76fb7be0.js";import"./_commonjsHelpers-de833af9.js";/* empty css                      */import"./UseRipple-565834b6.js";import"./TIcon-09805f2a.js";const E={title:"Guide/TToast",component:j},h=g=>{const t="Hello world",n="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry";function i(r){e(r)}function l(r){e.success(r)}function c(r){e.error(r)}function m(r){e.warn(r)}function d(r){e.info(r)}return s.jsxs(s.Fragment,{children:[s.jsx(o,{onClick:()=>i(t),children:"Plain short"}),s.jsx(o,{onClick:()=>i(n),children:"Plain long"}),s.jsx("br",{}),s.jsx("br",{}),s.jsx(o,{onClick:()=>l(t),children:"Success short"}),s.jsx(o,{onClick:()=>l(n),children:"Success long"}),s.jsx("br",{}),s.jsx("br",{}),s.jsx(o,{onClick:()=>c(t),children:"Error short"}),s.jsx(o,{onClick:()=>c(n),children:"Error long"}),s.jsx("br",{}),s.jsx("br",{}),s.jsx(o,{onClick:()=>m(t),children:"Warn short"}),s.jsx(o,{onClick:()=>m(n),children:"Warn long"}),s.jsx("br",{}),s.jsx("br",{}),s.jsx(o,{onClick:()=>d(t),children:"Info short"}),s.jsx(o,{onClick:()=>d(n),children:"Info long"}),s.jsx("br",{}),s.jsx("br",{}),s.jsx(j,{...g})]})},a={render:h,args:{className:"tks-toast-container",autoClose:5e3,toastClassName:"tks-toast",bodyClassName:"tks-toast__body",progressClassName:"tks-toast__progress",position:"top-right",draggable:!1}};var p,x,u;a.parameters={...a.parameters,docs:{...(p=a.parameters)==null?void 0:p.docs,source:{originalSource:`{
  render: Template,
  args: {
    className: 'tks-toast-container',
    autoClose: 5000,
    toastClassName: 'tks-toast',
    bodyClassName: 'tks-toast__body',
    progressClassName: 'tks-toast__progress',
    position: ('top-right' as ToastPosition),
    draggable: false
  }
}`,...(u=(x=a.parameters)==null?void 0:x.docs)==null?void 0:u.source}}};const I=["Default"];export{a as Default,I as __namedExportsOrder,E as default};
