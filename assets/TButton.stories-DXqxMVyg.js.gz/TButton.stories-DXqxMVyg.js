import{j as e}from"./jsx-runtime-Nms4Y4qS.js";import{a as t}from"./TButtonGroup-C9dzEbh2.js";import"./index-BwDkhjyp.js";import"./_commonjsHelpers-BosuxZz1.js";import"./TIconButton-dmkO_F7M.js";import"./UseRipple-B9sLGhCT.js";import"./uniqueId-BdmaqBQH.js";import"./toString-Biug5Hwg.js";import"./TIcon-Cxgxukqq.js";import"./ThemeToken.module-BX06fUfM.js";import"./index-Dk74W0Oi.js";import"./index-B8XB3FuZ.js";import"./TBadge-CoF-KBLQ.js";import"./UseValidator-o4VEqFQR.js";/* empty css                      */import"./TDropHolder-CUn4zPRX.js";import"./TPage-CTdTv5C0.js";import"./TTooltip-Y3wDWRGN.js";import"./THighlightText-BwpA2dOG.js";import"./TTabItem-GvFX-zLb.js";import"./TCardContent-BOqVmtMU.js";import"./TInputValidationHint-DVejngM-.js";import"./TChip-Cvj8MdUf.js";import"./TTextField-6R9FQZxS.js";import"./TSwitch-Bm5SUfmf.js";const Y={title:"Button/TButton",component:t},d=({label:r,children:L})=>e.jsxs("div",{style:{display:"flex",alignItems:"flex-start",flexDirection:"column",gap:"8px"},children:[e.jsx("p",{style:{fontSize:"14px"},children:r}),e.jsx("div",{style:{display:"flex",alignItems:"center",gap:"8px"},children:L})]}),n=r=>e.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:"32px"},children:[e.jsxs(d,{label:"Default",children:[e.jsx(t,{...r,children:"Normal"}),e.jsx(t,{...r,primary:!0,children:"Primary"}),e.jsx(t,{...r,main:!0,children:"Main"}),e.jsx(t,{...r,ghost:!0,children:"Ghost"}),e.jsx(t,{...r,rounded:!0,children:"Rounded"}),e.jsx(t,{...r,icon:"info",children:"Icon Button"})]}),e.jsxs(d,{label:"Disabled",children:[e.jsx(t,{...r,disabled:!0,children:"Normal"}),e.jsx(t,{...r,primary:!0,disabled:!0,children:"Primary"}),e.jsx(t,{...r,main:!0,disabled:!0,children:"Main"}),e.jsx(t,{...r,ghost:!0,disabled:!0,children:"Ghost"}),e.jsx(t,{...r,rounded:!0,disabled:!0,children:"Rounded"}),e.jsx(t,{...r,icon:"info",disabled:!0,children:"Icon Button"})]}),e.jsxs(d,{label:"Loading",children:[e.jsx(t,{...r,loading:!0,children:"plain"}),e.jsx(t,{...r,primary:!0,loading:!0,children:"primary"}),e.jsx(t,{...r,main:!0,loading:!0,children:"main"}),e.jsx(t,{...r,ghost:!0,loading:!0,children:"point"}),e.jsx(t,{...r,rounded:!0,loading:!0,children:"rounded"}),e.jsx(t,{...r,icon:"info",loading:!0,children:"Icon Button"})]})]}),o={render:n,args:{xsmall:!0}},i={render:n,args:{small:!0}},a={render:n,args:{medium:!0}},s={render:n,args:{large:!0}},l={render:n,args:{xlarge:!0}};var m,c,p;o.parameters={...o.parameters,docs:{...(m=o.parameters)==null?void 0:m.docs,source:{originalSource:`{
  render: Template,
  args: {
    xsmall: true
  }
}`,...(p=(c=o.parameters)==null?void 0:c.docs)==null?void 0:p.source}}};var u,x,h;i.parameters={...i.parameters,docs:{...(u=i.parameters)==null?void 0:u.docs,source:{originalSource:`{
  render: Template,
  args: {
    small: true
  }
}`,...(h=(x=i.parameters)==null?void 0:x.docs)==null?void 0:h.source}}};var j,g,f;a.parameters={...a.parameters,docs:{...(j=a.parameters)==null?void 0:j.docs,source:{originalSource:`{
  render: Template,
  args: {
    medium: true
  }
}`,...(f=(g=a.parameters)==null?void 0:g.docs)==null?void 0:f.source}}};var y,b,S;s.parameters={...s.parameters,docs:{...(y=s.parameters)==null?void 0:y.docs,source:{originalSource:`{
  render: Template,
  args: {
    large: true
  }
}`,...(S=(b=s.parameters)==null?void 0:b.docs)==null?void 0:S.source}}};var T,B,I;l.parameters={...l.parameters,docs:{...(T=l.parameters)==null?void 0:T.docs,source:{originalSource:`{
  render: Template,
  args: {
    xlarge: true
  }
}`,...(I=(B=l.parameters)==null?void 0:B.docs)==null?void 0:I.source}}};const Z=["XSmall","Small","Medium","Large","XLarge"];export{s as Large,a as Medium,i as Small,l as XLarge,o as XSmall,Z as __namedExportsOrder,Y as default};
