import{j as e}from"./jsx-runtime-ffb262ed.js";import{T as r}from"./TButton-7a565153.js";import"./index-76fb7be0.js";import"./_commonjsHelpers-de833af9.js";import"./UseRipple-bad4b27c.js";import"./TIcon-a8804371.js";const M={title:"Button/TButton",component:r},o=n=>e.jsxs(e.Fragment,{children:[e.jsx(r,{...n,children:"plain"}),e.jsx(r,{...n,primary:!0,children:"primary"}),e.jsx(r,{...n,main:!0,children:"main"}),e.jsx(r,{...n,point:!0,children:"point"}),e.jsx(r,{...n,rounded:!0,children:"rounded"}),e.jsx("br",{})," ",e.jsx("br",{}),e.jsx(r,{...n,disabled:!0,children:"plain"}),e.jsx(r,{...n,primary:!0,disabled:!0,children:"primary"}),e.jsx(r,{...n,main:!0,disabled:!0,children:"main"}),e.jsx(r,{...n,point:!0,disabled:!0,children:"point"}),e.jsx(r,{...n,rounded:!0,disabled:!0,children:"rounded"}),e.jsx("br",{})," ",e.jsx("br",{}),e.jsx(r,{...n,loading:!0,children:"plain"}),e.jsx(r,{...n,primary:!0,loading:!0,children:"primary"}),e.jsx(r,{...n,main:!0,loading:!0,children:"main"}),e.jsx(r,{...n,point:!0,loading:!0,children:"point"}),e.jsx(r,{...n,rounded:!0,loading:!0,children:"rounded"})]}),t={render:o,args:{xsmall:!0}},a={render:o,args:{small:!0}},s={render:o,args:{medium:!0}},d={render:o,args:{large:!0}};var i,m,l;t.parameters={...t.parameters,docs:{...(i=t.parameters)==null?void 0:i.docs,source:{originalSource:`{
  render: Template,
  args: {
    xsmall: true
  }
}`,...(l=(m=t.parameters)==null?void 0:m.docs)==null?void 0:l.source}}};var u,c,p;a.parameters={...a.parameters,docs:{...(u=a.parameters)==null?void 0:u.docs,source:{originalSource:`{
  render: Template,
  args: {
    small: true
  }
}`,...(p=(c=a.parameters)==null?void 0:c.docs)==null?void 0:p.source}}};var x,j,h;s.parameters={...s.parameters,docs:{...(x=s.parameters)==null?void 0:x.docs,source:{originalSource:`{
  render: Template,
  args: {
    medium: true
  }
}`,...(h=(j=s.parameters)==null?void 0:j.docs)==null?void 0:h.source}}};var b,g,S;d.parameters={...d.parameters,docs:{...(b=d.parameters)==null?void 0:b.docs,source:{originalSource:`{
  render: Template,
  args: {
    large: true
  }
}`,...(S=(g=d.parameters)==null?void 0:g.docs)==null?void 0:S.source}}};const X=["XSmall","Small","Medium","Large"];export{d as Large,s as Medium,a as Small,t as XSmall,X as __namedExportsOrder,M as default};
//# sourceMappingURL=TButton.stories-8085d290.js.map
