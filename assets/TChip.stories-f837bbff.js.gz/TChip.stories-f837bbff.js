import{j as e}from"./jsx-runtime-ffb262ed.js";import{T as o}from"./TChip-aa5ce37d.js";import{n,T as _}from"./TToast-dec64875.js";import"./index-76fb7be0.js";import"./_commonjsHelpers-de833af9.js";import"./TIcon-09805f2a.js";/* empty css                      */const B={title:"Input/TChip",component:o},t=r=>e.jsx("div",{style:{marginBottom:"16px",display:"flex",alignItems:"center"},children:r.children}),l=r=>e.jsxs(e.Fragment,{children:[e.jsxs(t,{children:[e.jsx(o,{...r,children:"hello"}),e.jsx(o,{...r,onRemove:()=>{n("삭제 이벤트 발생")},children:"hello"}),e.jsx(o,{...r,onRemove:()=>{n("삭제 이벤트 발생")},removeIcon:"cleaning_bucket",children:"hello"}),e.jsx(o,{...r,icon:"face",children:"hello"}),e.jsx(o,{...r,icon:"face",onRemove:()=>{n("삭제 이벤트 발생")},children:"hello"})]}),e.jsxs(t,{children:[e.jsx(o,{...r,primary:!0,children:"hello"}),e.jsx(o,{...r,primary:!0,onRemove:()=>{n("삭제 이벤트 발생")},children:"hello"}),e.jsx(o,{...r,primary:!0,onRemove:()=>{n("삭제 이벤트 발생")},removeIcon:"cleaning_bucket",children:"hello"}),e.jsx(o,{...r,primary:!0,icon:"face",children:"hello"}),e.jsx(o,{...r,primary:!0,icon:"face",onRemove:()=>{n("삭제 이벤트 발생")},children:"hello"})]}),e.jsxs(t,{children:[e.jsx(o,{...r,type:"outlined",children:"hello"}),e.jsx(o,{...r,type:"outlined",onRemove:()=>{n("삭제 이벤트 발생")},children:"hello"}),e.jsx(o,{...r,type:"outlined",onRemove:()=>{n("삭제 이벤트 발생")},removeIcon:"cleaning_bucket",children:"hello"}),e.jsx(o,{...r,type:"outlined",icon:"face",children:"hello"}),e.jsx(o,{...r,type:"outlined",icon:"face",onRemove:()=>{n("삭제 이벤트 발생")},children:"hello"})]}),e.jsxs(t,{children:[e.jsx(o,{...r,type:"outlined",primary:!0,children:"hello"}),e.jsx(o,{...r,type:"outlined",primary:!0,onRemove:()=>{n("삭제 이벤트 발생")},children:"hello"}),e.jsx(o,{...r,type:"outlined",primary:!0,onRemove:()=>{n("삭제 이벤트 발생")},removeIcon:"cleaning_bucket",children:"hello"}),e.jsx(o,{...r,type:"outlined",primary:!0,icon:"face",children:"hello"}),e.jsx(o,{...r,type:"outlined",primary:!0,icon:"face",onRemove:()=>{n("삭제 이벤트 발생")},children:"hello"})]}),e.jsx(_,{})]}),i={render:l,args:{onRemove:void 0,xsmall:!0}},a={render:l,args:{onRemove:void 0,small:!0}},m={render:l,args:{onRemove:void 0,medium:!0}},c={render:l,args:{onRemove:void 0,large:!0}},s={render:l,args:{onRemove:void 0,xlarge:!0}};var d,p,u;i.parameters={...i.parameters,docs:{...(d=i.parameters)==null?void 0:d.docs,source:{originalSource:`{
  render: NormalTemplate,
  args: {
    onRemove: undefined,
    xsmall: true
  }
}`,...(u=(p=i.parameters)==null?void 0:p.docs)==null?void 0:u.source}}};var h,x,v;a.parameters={...a.parameters,docs:{...(h=a.parameters)==null?void 0:h.docs,source:{originalSource:`{
  render: NormalTemplate,
  args: {
    onRemove: undefined,
    small: true
  }
}`,...(v=(x=a.parameters)==null?void 0:x.docs)==null?void 0:v.source}}};var j,y,R;m.parameters={...m.parameters,docs:{...(j=m.parameters)==null?void 0:j.docs,source:{originalSource:`{
  render: NormalTemplate,
  args: {
    onRemove: undefined,
    medium: true
  }
}`,...(R=(y=m.parameters)==null?void 0:y.docs)==null?void 0:R.source}}};var f,T,g;c.parameters={...c.parameters,docs:{...(f=c.parameters)==null?void 0:f.docs,source:{originalSource:`{
  render: NormalTemplate,
  args: {
    onRemove: undefined,
    large: true
  }
}`,...(g=(T=c.parameters)==null?void 0:T.docs)==null?void 0:g.source}}};var S,I,N;s.parameters={...s.parameters,docs:{...(S=s.parameters)==null?void 0:S.docs,source:{originalSource:`{
  render: NormalTemplate,
  args: {
    onRemove: undefined,
    xlarge: true
  }
}`,...(N=(I=s.parameters)==null?void 0:I.docs)==null?void 0:N.source}}};const F=["XSmall","Small","Medium","Large","XLarge"];export{c as Large,m as Medium,a as Small,s as XLarge,i as XSmall,F as __namedExportsOrder,B as default};
