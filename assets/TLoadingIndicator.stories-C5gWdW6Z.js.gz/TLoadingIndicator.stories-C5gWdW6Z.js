import{j as e}from"./jsx-runtime-Nms4Y4qS.js";import{k as r}from"./TButtonGroup-C9dzEbh2.js";import"./TIconButton-dmkO_F7M.js";import"./TDropHolder-CUn4zPRX.js";import"./TPage-CTdTv5C0.js";import"./THighlightText-BwpA2dOG.js";import"./TTabItem-GvFX-zLb.js";import"./TCardContent-BOqVmtMU.js";import"./TBadge-CoF-KBLQ.js";import"./TInputValidationHint-DVejngM-.js";import"./TChip-Cvj8MdUf.js";import"./TTooltip-Y3wDWRGN.js";import"./TIcon-Cxgxukqq.js";import"./TSwitch-Bm5SUfmf.js";import"./TTextField-6R9FQZxS.js";import"./index-BwDkhjyp.js";import"./_commonjsHelpers-BosuxZz1.js";import"./index-Dk74W0Oi.js";import"./index-B8XB3FuZ.js";import"./ThemeToken.module-BX06fUfM.js";import"./UseValidator-o4VEqFQR.js";import"./UseRipple-B9sLGhCT.js";import"./uniqueId-BdmaqBQH.js";import"./toString-Biug5Hwg.js";/* empty css                      */const W={title:"Guide/TLoadingIndicator",component:r},a=s=>e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"16px"},children:[e.jsx(r,{...s,size:"xsmall"}),e.jsx(r,{...s,size:"small"}),e.jsx(r,{...s,size:"medium"}),e.jsx(r,{...s,size:"large"}),e.jsx(r,{...s,size:"xlarge"})]}),t={render:a,args:{}},o={render:a,args:{variant:"default",message:"데이터를 불러오고 있습니다."}},n={render:a,args:{variant:"sun"}},m={render:a,args:{variant:"sun",message:"데이터를 불러오고 있습니다."}},u={render:a,args:{variant:"sun",message:"로딩 중...",color:"violet"}};var i,p,c;t.parameters={...t.parameters,docs:{...(i=t.parameters)==null?void 0:i.docs,source:{originalSource:`{
  render: Template,
  args: {}
}`,...(c=(p=t.parameters)==null?void 0:p.docs)==null?void 0:c.source}}};var d,l,g;o.parameters={...o.parameters,docs:{...(d=o.parameters)==null?void 0:d.docs,source:{originalSource:`{
  render: Template,
  args: {
    variant: 'default',
    message: '데이터를 불러오고 있습니다.'
  }
}`,...(g=(l=o.parameters)==null?void 0:l.docs)==null?void 0:g.source}}};var C,B,x;n.parameters={...n.parameters,docs:{...(C=n.parameters)==null?void 0:C.docs,source:{originalSource:`{
  render: Template,
  args: {
    variant: 'sun'
  }
}`,...(x=(B=n.parameters)==null?void 0:B.docs)==null?void 0:x.source}}};var v,f,j;m.parameters={...m.parameters,docs:{...(v=m.parameters)==null?void 0:v.docs,source:{originalSource:`{
  render: Template,
  args: {
    variant: 'sun',
    message: '데이터를 불러오고 있습니다.'
  }
}`,...(j=(f=m.parameters)==null?void 0:f.docs)==null?void 0:j.source}}};var E,T,D;u.parameters={...u.parameters,docs:{...(E=u.parameters)==null?void 0:E.docs,source:{originalSource:`{
  render: Template,
  args: {
    variant: 'sun',
    message: '로딩 중...',
    color: 'violet'
  }
}`,...(D=(T=u.parameters)==null?void 0:T.docs)==null?void 0:D.source}}};const X=["Default","defaultMessage","sun","sunMessage","custom"];export{t as Default,X as __namedExportsOrder,u as custom,W as default,o as defaultMessage,n as sun,m as sunMessage};
