import{j as s}from"./jsx-runtime-CKrituN3.js";import{T as j,n as e}from"./TToast-B8C8rUdq.js";import{T as o}from"./TButton-CY0yEcNN.js";import"./index-CBqU2yxZ.js";import"./_commonjsHelpers-BosuxZz1.js";/* empty css                      */import"./UseRipple-B0f24SXl.js";import"./uniqueId-BdmaqBQH.js";import"./toString-Biug5Hwg.js";import"./TIcon-DX3nHo9a.js";const w={title:"Guide/TToast",component:j},h=g=>{const t="Hello world",n="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry";function i(r){e(r)}function l(r){e.success(r)}function c(r){e.error(r)}function m(r){e.warn(r)}function p(r){e.info(r)}return s.jsxs(s.Fragment,{children:[s.jsx(o,{onClick:()=>i(t),children:"Plain short"}),s.jsx(o,{onClick:()=>i(n),children:"Plain long"}),s.jsx("br",{}),s.jsx("br",{}),s.jsx(o,{onClick:()=>l(t),children:"Success short"}),s.jsx(o,{onClick:()=>l(n),children:"Success long"}),s.jsx("br",{}),s.jsx("br",{}),s.jsx(o,{onClick:()=>c(t),children:"Error short"}),s.jsx(o,{onClick:()=>c(n),children:"Error long"}),s.jsx("br",{}),s.jsx("br",{}),s.jsx(o,{onClick:()=>m(t),children:"Warn short"}),s.jsx(o,{onClick:()=>m(n),children:"Warn long"}),s.jsx("br",{}),s.jsx("br",{}),s.jsx(o,{onClick:()=>p(t),children:"Info short"}),s.jsx(o,{onClick:()=>p(n),children:"Info long"}),s.jsx("br",{}),s.jsx("br",{}),s.jsx(j,{...g})]})},a={render:h,args:{className:"tks-toast-container",autoClose:5e3,toastClassName:"tks-toast",bodyClassName:"tks-toast__body",progressClassName:"tks-toast__progress",position:"top-right",draggable:!1}};var d,x,u;a.parameters={...a.parameters,docs:{...(d=a.parameters)==null?void 0:d.docs,source:{originalSource:`{
  render: Template,
  args: {
    className: 'tks-toast-container',
    autoClose: 5000,
    toastClassName: 'tks-toast',
    bodyClassName: 'tks-toast__body',
    progressClassName: 'tks-toast__progress',
    position: ('top-right' as ToastPosition),
    draggable: false
  }
}`,...(u=(x=a.parameters)==null?void 0:x.docs)==null?void 0:u.source}}};const P=["Default"];export{a as Default,P as __namedExportsOrder,w as default};
