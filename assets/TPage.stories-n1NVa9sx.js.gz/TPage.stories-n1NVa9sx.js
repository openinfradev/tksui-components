import{j as e}from"./jsx-runtime-CKrituN3.js";import{T as m}from"./TPage-BVThT5cJ.js";import{T as t}from"./TSection-IZqRhGi2.js";import"./index-CBqU2yxZ.js";import"./_commonjsHelpers-BosuxZz1.js";import"./TIcon-CuhwYyyf.js";const T={title:"Screen/TPage",component:m},u=`
Lorem ipsum dolor sit amet, consec
tetur adipiscing elit. In nec consecte
tur justo, in faucibus nisl. Donec acc
umsan, sem non pellentesque ullam
corper, diam lectus cursus urna, 
in euismod dui risus vitae massa. 
Donec pretium faucibus placerat. 
Nulla facilisi. Proin ultricies, 
nulla eget efficitur facilisis, orci quam acc
umsan nulla, eget condimentum pur
us massa eu velit. Suspendisse fring
illa ex ex, in facilisis urna sagittis vel. Cras sit amet mattis urna. Etiam vehi
cula cursus lorem ac tempor.`,x=j=>e.jsx(e.Fragment,{children:e.jsxs(m,{title:"클러스터 관리",...j,children:[e.jsx(t,{label:"컨텐츠 1",children:e.jsxs("p",{children:["여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{})]})}),e.jsx(t,{label:"컨텐츠 2",children:e.jsxs("p",{children:["여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{})]})})]})}),r={render:x,args:{infoPanelContent:u}},s={render:x,args:{infoPanelContent:u,contentDirection:"left-right"}};var n,i,a;r.parameters={...r.parameters,docs:{...(n=r.parameters)==null?void 0:n.docs,source:{originalSource:`{
  render: Template,
  args: {
    infoPanelContent: infoContent
  }
}`,...(a=(i=r.parameters)==null?void 0:i.docs)==null?void 0:a.source}}};var o,c,l;s.parameters={...s.parameters,docs:{...(o=s.parameters)==null?void 0:o.docs,source:{originalSource:`{
  render: Template,
  args: {
    infoPanelContent: infoContent,
    contentDirection: 'left-right'
  }
}`,...(l=(c=s.parameters)==null?void 0:c.docs)==null?void 0:l.source}}};const C=["TopBottom","LeftRight"];export{s as LeftRight,r as TopBottom,C as __namedExportsOrder,T as default};
