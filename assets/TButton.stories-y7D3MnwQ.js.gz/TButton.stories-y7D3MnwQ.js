import{j as e}from"./jsx-runtime-D_zvdyIk.js";import{a as t}from"./TButtonGroup-C-mJGCKi.js";import"./index-75N07mRN.js";import"./TTabItem-DPqjR3tx.js";import"./TIcon-DLBXrsGZ.js";import"./index-BJirbR3n.js";import"./index-Bj-N6E0A.js";import"./TBadge-B58EEO3d.js";import"./UseValidator-BSroX4ym.js";import"./TDropHolder-CeUkRMWI.js";import"./THighlightText-pTj3K_4-.js";import"./TInputValidationHint-DqK32PRs.js";import"./TChip-KzMSgKKz.js";import"./TTextField-Cw9y-yB4.js";import"./TSwitch-DoTj_LFj.js";const w={title:"Button/TButton",component:t},d=({label:r,children:L})=>e.jsxs("div",{style:{display:"flex",alignItems:"flex-start",flexDirection:"column",gap:"8px"},children:[e.jsx("p",{style:{fontSize:"14px"},children:r}),e.jsx("div",{style:{display:"flex",alignItems:"center",gap:"8px"},children:L})]}),n=r=>e.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:"32px"},children:[e.jsxs(d,{label:"Default",children:[e.jsx(t,{...r,children:"Normal"}),e.jsx(t,{...r,primary:!0,children:"Primary"}),e.jsx(t,{...r,main:!0,children:"Main"}),e.jsx(t,{...r,ghost:!0,children:"Ghost"}),e.jsx(t,{...r,rounded:!0,children:"Rounded"}),e.jsx(t,{...r,icon:"info",children:"Icon Button"})]}),e.jsxs(d,{label:"Disabled",children:[e.jsx(t,{...r,disabled:!0,children:"Normal"}),e.jsx(t,{...r,primary:!0,disabled:!0,children:"Primary"}),e.jsx(t,{...r,main:!0,disabled:!0,children:"Main"}),e.jsx(t,{...r,ghost:!0,disabled:!0,children:"Ghost"}),e.jsx(t,{...r,rounded:!0,disabled:!0,children:"Rounded"}),e.jsx(t,{...r,icon:"info",disabled:!0,children:"Icon Button"})]}),e.jsxs(d,{label:"Loading",children:[e.jsx(t,{...r,loading:!0,children:"plain"}),e.jsx(t,{...r,primary:!0,loading:!0,children:"primary"}),e.jsx(t,{...r,main:!0,loading:!0,children:"main"}),e.jsx(t,{...r,ghost:!0,loading:!0,children:"point"}),e.jsx(t,{...r,rounded:!0,loading:!0,children:"rounded"}),e.jsx(t,{...r,icon:"info",loading:!0,children:"Icon Button"})]})]}),a={render:n,args:{xsmall:!0}},s={render:n,args:{small:!0}},o={render:n,args:{medium:!0}},i={render:n,args:{large:!0}},l={render:n,args:{xlarge:!0}};var m,c,u;a.parameters={...a.parameters,docs:{...(m=a.parameters)==null?void 0:m.docs,source:{originalSource:`{
  render: Template,
  args: {
    xsmall: true
  }
}`,...(u=(c=a.parameters)==null?void 0:c.docs)==null?void 0:u.source}}};var p,x,h;s.parameters={...s.parameters,docs:{...(p=s.parameters)==null?void 0:p.docs,source:{originalSource:`{
  render: Template,
  args: {
    small: true
  }
}`,...(h=(x=s.parameters)==null?void 0:x.docs)==null?void 0:h.source}}};var j,g,f;o.parameters={...o.parameters,docs:{...(j=o.parameters)==null?void 0:j.docs,source:{originalSource:`{
  render: Template,
  args: {
    medium: true
  }
}`,...(f=(g=o.parameters)==null?void 0:g.docs)==null?void 0:f.source}}};var y,b,S;i.parameters={...i.parameters,docs:{...(y=i.parameters)==null?void 0:y.docs,source:{originalSource:`{
  render: Template,
  args: {
    large: true
  }
}`,...(S=(b=i.parameters)==null?void 0:b.docs)==null?void 0:S.source}}};var T,B,I;l.parameters={...l.parameters,docs:{...(T=l.parameters)==null?void 0:T.docs,source:{originalSource:`{
  render: Template,
  args: {
    xlarge: true
  }
}`,...(I=(B=l.parameters)==null?void 0:B.docs)==null?void 0:I.source}}};const A=["XSmall","Small","Medium","Large","XLarge"];export{i as Large,o as Medium,s as Small,l as XLarge,a as XSmall,A as __namedExportsOrder,w as default};
