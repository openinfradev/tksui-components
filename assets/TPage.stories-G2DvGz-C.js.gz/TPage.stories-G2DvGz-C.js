import{j as e}from"./jsx-runtime-vNq4Oc-g.js";import{T as a}from"./TPage-J__BDzFA.js";import"./index-4g5l5LRQ.js";import"./_commonjsHelpers-4gQjN7DL.js";import"./TIcon-bZ1YQzj2.js";const j={title:"Screen/TPage",component:a},o=`
Lorem ipsum dolor sit amet, consec
tetur adipiscing elit. In nec consecte
tur justo, in faucibus nisl. Donec acc
umsan, sem non pellentesque ullam
corper, diam lectus cursus urna, 
in euismod dui risus vitae massa. 
Donec pretium faucibus placerat. 
Nulla facilisi. Proin ultricies, 
nulla eget efficitur facilisis, orci quam acc
umsan nulla, eget condimentum pur
us massa eu velit. Suspendisse fring
illa ex ex, in facilisis urna sagittis vel. Cras sit amet mattis urna. Etiam vehi
cula cursus lorem ac tempor.`,c=i=>e.jsx(e.Fragment,{children:e.jsx(a,{title:"클러스터 관리",...i,children:e.jsxs("p",{children:["여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{}),"여기에 컨텐츠를 구현합니다. ",e.jsx("br",{})]})})}),s={render:c,args:{infoPanelContent:o}};var r,t,n;s.parameters={...s.parameters,docs:{...(r=s.parameters)==null?void 0:r.docs,source:{originalSource:`{
  render: Template,
  args: {
    infoPanelContent: infoContent
  }
}`,...(n=(t=s.parameters)==null?void 0:t.docs)==null?void 0:n.source}}};const d=["Default"];export{s as Default,d as __namedExportsOrder,j as default};
